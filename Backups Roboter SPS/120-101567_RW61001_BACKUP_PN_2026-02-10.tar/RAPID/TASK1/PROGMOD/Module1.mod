MODULE Module1
    
    
PROC Main()
    ! Enable Conveyer belts
    Enable_Conveyerbelts;
    ! Wait 1 second
    WaitTime 1;
    ! Turn on Camera conveyer belt with 20 velocity
    Turn_ON_Camera_Conveyer(20);
    ! Wait for 10 seconds
    WaitTime 10;
    ! Turn off Camera conveyer belt
    Turn_OFF_Camera_Conveyer;
    ! Wait for 5 Seconds
    WaitTime 5;
    ! Eject one part
    Eject_Part;
    ! Wait for 5 seconds
    WaitTime 5;
    ! Disable conveyer belts
    Disable_Conveyerbelts;
    ! Wait for 5 seconds
    WaitTime 5;
ENDPROC
ENDMODULE