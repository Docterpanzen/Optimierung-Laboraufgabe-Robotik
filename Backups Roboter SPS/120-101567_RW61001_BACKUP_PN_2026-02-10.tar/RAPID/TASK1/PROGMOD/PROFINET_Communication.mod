MODULE PROFINET_Communication


!    _______    ______         __    __   ______  ________        ________  _______   ______  ________ 
!   |       \  /      \       |  \  |  \ /      \|        \      |        \|       \ |      \|        \
!   | $$$$$$$\|  $$$$$$\      | $$\ | $$|  $$$$$$\\$$$$$$$$      | $$$$$$$$| $$$$$$$\ \$$$$$$ \$$$$$$$$
!   | $$  | $$| $$  | $$      | $$$\| $$| $$  | $$  | $$         | $$__    | $$  | $$  | $$     | $$   
!   | $$  | $$| $$  | $$      | $$$$\ $$| $$  | $$  | $$         | $$  \   | $$  | $$  | $$     | $$   
!   | $$  | $$| $$  | $$      | $$\$$ $$| $$  | $$  | $$         | $$$$$   | $$  | $$  | $$     | $$   
!   | $$__/ $$| $$__/ $$      | $$ \$$$$| $$__/ $$  | $$         | $$_____ | $$__/ $$ _| $$_    | $$   
!   | $$    $$ \$$    $$      | $$  \$$$ \$$    $$  | $$         | $$     \| $$    $$|   $$ \   | $$   
!    \$$$$$$$   \$$$$$$        \$$   \$$  \$$$$$$    \$$          \$$$$$$$$ \$$$$$$$  \$$$$$$    \$$       
!
!                                                 uuuuuuu
!                                             uu$$$$$$$$$$$uu
!                                          uu$$$$$$$$$$$$$$$$$uu
!                                         u$$$$$$$$$$$$$$$$$$$$$u
!                                        u$$$$$$$$$$$$$$$$$$$$$$$u
!                                       u$$$$$$$$$$$$$$$$$$$$$$$$$u
!                                       u$$$$$$$$$$$$$$$$$$$$$$$$$u
!                                       u$$$$$$"   "$$$"   "$$$$$$u
!                                       "$$$$"      u$u       $$$$"
!                                        $$$u       u$u       u$$$
!                                        $$$u      u$$$u      u$$$
!                                         "$$$$uu$$$   $$$uu$$$$"
!                                          "$$$$$$$"   "$$$$$$$"
!                                            u$$$$$$$u$$$$$$$u
!                                             u$"$"$"$"$"$"$u
!                                  uuu        $$u$ $ $ $ $u$$       uuu
!                                 u$$$$        $$$$$u$u$u$$$       u$$$$
!                                  $$$$$uu      "$$$$$$$$$"     uu$$$$$$
!                                u$$$$$$$$$$$uu    """""    uuuu$$$$$$$$$$
!                                $$$$"""$$$$$$$$$$uuu   uu$$$$$$$$$"""$$$"
!                                 """      ""$$$$$$$$$$$uu ""$"""
!                                           uuuu ""$$$$$$$$$$uuu
!                                  u$$$uuu$$$$$$$$$uu ""$$$$$$$$$$$uuu$$$
!                                  $$$$$$$$$$""""           ""$$$$$$$$$$$"
!                                   "$$$$$"                      ""$$$$""
!                                     $$$"                         $$$$"




   
!*****************************************************
! Enable both Conveyerbelts !
! This Procedure enables both conveyer belts
!*****************************************************
PROC Enable_Conveyerbelts()
    IF PN_Error = 1 THEN
        ERROR_HANDLING;
    ENDIF
    SetDO PN_Enable_Conveyer, 1;
    WaitDI PN_Ready, 1;
    RETURN;
ENDPROC


!*****************************************************
! Disable both Conveyerbelts !
! This Procedure disables both conveyer belts
!*****************************************************
PROC Disable_Conveyerbelts()
    IF PN_Error = 1 THEN
        ERROR_HANDLING;
    ENDIF
    SetDO PN_Enable_Conveyer, 0;
    WaitDI PN_Ready, 0;
    RETURN;
ENDPROC

!*****************************************************
! Turn ON Camera Conveyer !
! This Procedure Turns on the Camera Conveyer 
! Belt with a Velocity as input iVelocity := 0-80
!*****************************************************

PROC Turn_ON_Camera_Conveyer(num iVelocity)
    IF PN_Error = 1 THEN
        ERROR_HANDLING;
    ENDIF
    setGO PN_Velocity_Camera, iVelocity;
    SetDO PN_Execute_Camera, 1;
    WaitDI PN_Conv_Camera_Moving, 1;
    RETURN;
ENDPROC

!*****************************************************
! Turn ON Camera Conveyer !
! This Procedure Turns off the Camera Conveyer 
!*****************************************************
PROC Turn_OFF_Camera_Conveyer()
    IF PN_Error = 1 THEN
        ERROR_HANDLING;
    ENDIF
    SetDO PN_Execute_Camera, 0;
    WaitDI PN_Conv_Camera_Moving, 0;
    RETURN;
ENDPROC

!*****************************************************
! Eject Part !
! This Procedure moves the part 
! conveyer belt for one Position
!*****************************************************
PROC Eject_Part()
    IF PN_Error = 1 THEN
        ERROR_HANDLING;
    ENDIF
    SetDO PN_Execute_Part, 1;
    WaitTime 0.1;
    SetDO PN_Execute_Part, 0;
    WaitDI PN_PartEjected, 1;
    RETURN;
ENDPROC


!*****************************************************
! ERROR HANDLING !
! This Procedure gives Error Messages based on which Error occours
!*****************************************************
PROC ERROR_HANDLING()
    VAR btnres Reset;
    IF PN_Error_EStop = 1 THEN
        UIMsgBox
            \Header:="ERROR",
            "Emergency Stop of PLC pressed"
            \MsgLine2:="Please release the Emergency Stop and press the Reset Button of the PLC"
            \Buttons:=btnRetryCancel
            \Icon:=iconError
            \Result:=Reset;
        IF Reset = resRetry THEN
            Main;
        ELSE
          EXIT;  
        ENDIF
    ELSEIF PN_ErrorIDCamera > 0 THEN
        UIMsgBox
            \Header:="ERROR",
            "Camera conveyerbelt Error"
            \MsgLine2:="Please check the PLC-Programm for further Error description"
            \Buttons:=btnRetryCancel
            \Icon:=iconError
            \Result:=Reset;
        IF Reset = resRetry THEN
            Main;
        ELSE
          EXIT;  
        ENDIF
    ELSEIF PN_ErrorIDPart > 0 THEN
        UIMsgBox
            \Header:="ERROR",
            "Part conveyerbelt Error"
            \MsgLine2:="Please check the PLC-Programm for further Error description"
            \Buttons:=btnRetryCancel
            \Icon:=iconError
            \Result:=Reset;
        IF Reset = resRetry THEN
            Main;
        ELSE
          EXIT;  
        ENDIF
    
    ELSEIF PN_Error_Safety > 0 THEN
        UIMsgBox
            \Header:="ERROR",
            "Internal PLC Safety Error"
            \MsgLine2:="Please check the PLC-Programm for further Error description"
            \Buttons:=btnRetryCancel
            \Icon:=iconError
            \Result:=Reset;
        IF Reset = resRetry THEN
            Main;
        ELSE
          EXIT;  
        ENDIF
    ENDIF
    
ENDPROC
ENDMODULE
